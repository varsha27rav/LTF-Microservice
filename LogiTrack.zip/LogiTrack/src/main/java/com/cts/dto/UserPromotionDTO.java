package com.cts.dto;

import com.cts.common.constants.Role;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor 
@AllArgsConstructor
public class UserPromotionDTO {
	@Schema(description = "The target role (e.g., ADMIN, DRIVER)")
    private Role newRole;

    @Schema(example = "ABC1234567", description = "License identifier, required for driver promotion")
    private String licenseNumber;

    @Schema(example = "+91-9876543210", description = "Primary contact information")
    private String contactInfo;
}