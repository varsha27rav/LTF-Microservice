package com.cts.entity;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "proof_of_receipts")
@Data
public class ProofOfReceipt {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long proofId;
    
    
    private Long deliveryId;
    private Long customerId;
    private LocalDateTime receivedAt;
    private String fileUri; // Path to digital signature or photo
    private String status; // VERIFIED
}