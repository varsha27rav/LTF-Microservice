package com.cts.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Table(name = "maintenance_records")
@Data
public class MaintenanceRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long maintId;

    private Long vehicleId;
    private Long inspectionId; // Link to the inspection that failed
    
    private String taskDescription; // What the manager said was wrong
    private String mechanicNotes;    // What the mechanic actually did
    private String performedBy;      // Mechanic Name
    private LocalDateTime performedAt;
    private Double cost;

    @Enumerated(EnumType.STRING)
    private MaintenanceStatus status = MaintenanceStatus.PENDING;

    public enum MaintenanceStatus {
        PENDING, IN_PROGRESS, COMPLETED
    }
}