package com.cts.entity;

import java.time.LocalDateTime;




import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "driver_assignments")
@Data
public class DriverAssignment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long assignId;
    
    private Long driverId; // FK to Driver entity
    private Long vehicleId;
    private Long routeId;
    private Long assignedBy; // Admin/Dispatcher ID
    private LocalDateTime assignedAt;
    private String status; // ACTIVE, COMPLETED
}