package com.cts.controller;

import com.cts.service.AuthService;
import com.cts.common.service.EmailService;
import com.cts.common.service.SmsService;
import com.cts.dto.LoginRequest;
import com.cts.dto.RegisterRequest;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService authService;
    private final EmailService emailService;
    private final SmsService smsService;

    public AuthController(AuthService authService, EmailService emailService, SmsService smsService) {
        this.authService = authService;
        this.emailService = emailService;
        this.smsService = smsService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest data) {
        // Pass the DTO instead of a Map
        return ResponseEntity.ok(Map.of("message", authService.registerUser(data)));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest data) {
        // Use the DTO getters
        String token = authService.login(data.getEmail(), data.getPassword());
        return ResponseEntity.ok(Map.of("token", token));
    }

    @PostMapping("/forgot-password/reset")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, String> data) {
        return ResponseEntity.ok(Map.of("message", 
            authService.resetPassword(data.get("email"), data.get("otpCode"), data.get("newPassword"))));
    }

    @PostMapping("/forgot-username/verify")
    public ResponseEntity<?> verifyUsername(@RequestBody Map<String, String> data) {
        String email = authService.recoverUsername(data.get("phoneNumber"), data.get("otpCode"));
        return ResponseEntity.ok(Map.of("username", "Your email is: " + email));
    }
}