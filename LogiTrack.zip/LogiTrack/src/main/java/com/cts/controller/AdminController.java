package com.cts.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.cts.common.constants.Role;
import com.cts.common.constants.Status;
import com.cts.dao.UserRepository;
import com.cts.dao.AuditLogRepository;
import com.cts.dao.RouteRepository;
import com.cts.dto.UserPromotionDTO;
import com.cts.entity.User;
import com.cts.entity.AuditLog;
import com.cts.entity.Route;
import com.cts.service.UserService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')") 
public class AdminController {

    private final UserService userService;
    private final UserRepository userRepository;
    private final AuditLogRepository auditLogRepository;
    private final RouteRepository routeRepository;

    public AdminController(UserService userService, UserRepository userRepository, 
                           AuditLogRepository auditLogRepository, RouteRepository routeRepository) {
        this.userService = userService;
        this.userRepository = userRepository;
        this.auditLogRepository = auditLogRepository;
        this.routeRepository = routeRepository;
    }

    // --- USER MANAGEMENT ---

    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userRepository.findAll());
    }

    @GetMapping("/users/role/{role}")
    public ResponseEntity<List<User>> getUsersByRole(@PathVariable Role role) {
        return ResponseEntity.ok(userRepository.findByRole(role));
    }

    @PutMapping("/users/{id}/updateRole")
    public ResponseEntity<Map<String, String>> promoteUser(@PathVariable Long id, @RequestBody UserPromotionDTO promotionDTO) {
        userService.promoteUser(id, promotionDTO);
        auditLogRepository.save(new AuditLog(id, "ROLE_UPDATE", "Admin updated user role to: " + promotionDTO.getNewRole()));
        return ResponseEntity.ok(Map.of("message", "User role updated to " + promotionDTO.getNewRole() + " successfully."));
    }

    @PutMapping("/users/{id}/reactivate")
    public ResponseEntity<Map<String, String>> reactivateUser(@PathVariable Long id) {
        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
        user.setStatus(Status.ACTIVE);
        userRepository.save(user);
        auditLogRepository.save(new AuditLog(id, "REACTIVATION", "Admin reactivated account for: " + user.getEmail()));
        return ResponseEntity.ok(Map.of("message", "User reactivated successfully."));
    }
    
    @DeleteMapping("/users/{id}")
    public ResponseEntity<Map<String, String>> deactivateUser(@PathVariable Long id) {
        userService.deactivateUser(id);
        auditLogRepository.save(new AuditLog(id, "DEACTIVATION", "Admin deactivated user ID: " + id));
        return ResponseEntity.ok(Map.of("message", "User deactivated successfully."));
    }

    // --- ROUTE MANAGEMENT ---

    @PostMapping("/routes")
    public ResponseEntity<Route> createRoute(@RequestBody Route route, Authentication auth) {
        Route saved = routeRepository.save(route);
        logAdminAction(auth, "ROUTE_CREATED", "Created route: " + saved.getName());
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/routes")
    public ResponseEntity<List<Route>> getAllRoutes() {
        return ResponseEntity.ok(routeRepository.findAll());
    }

    @PutMapping("/routes/{id}")
    public ResponseEntity<Route> updateRoute(@PathVariable Long id, @RequestBody Route details, Authentication auth) {
        Route route = routeRepository.findById(id).orElseThrow(() -> new RuntimeException("Route not found"));
        route.setName(details.getName());
        route.setStopsJson(details.getStopsJson());
        route.setDistanceKm(details.getDistanceKm());
        route.setStatus(details.getStatus());
        logAdminAction(auth, "ROUTE_UPDATED", "Updated route ID: " + id);
        return ResponseEntity.ok(routeRepository.save(route));
    }

    @DeleteMapping("/routes/{id}")
    public ResponseEntity<Map<String, String>> deleteRoute(@PathVariable Long id, Authentication auth) {
        routeRepository.deleteById(id);
        logAdminAction(auth, "ROUTE_DELETED", "Deleted route ID: " + id);
        return ResponseEntity.ok(Map.of("message", "Route deleted successfully"));
    }

    // --- SYSTEM MONITORING ---

    @GetMapping("/audit-logs")
    public ResponseEntity<List<AuditLog>> getAuditLogs() {
        return ResponseEntity.ok(auditLogRepository.findAllByOrderByTimestampDesc());
    }

    // Private helper to log which Admin performed the action
    private void logAdminAction(Authentication auth, String action, String details) {
        userRepository.findByEmail(auth.getName()).ifPresent(admin -> 
            auditLogRepository.save(new AuditLog(admin.getUserId(), action, details))
        );
    }
}