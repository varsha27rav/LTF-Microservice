package com.cts.config;

public class AppConfig {

}
