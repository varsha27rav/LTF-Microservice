package com.cts.service;

import com.cts.dao.*;
import com.cts.entity.*;
import com.cts.dto.DeliveryCompletionRequest;
import com.cts.dto.DriverRideResponse; // IMPORTANT: Ensure this import exists
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DriverService {

    private final ShipmentRepository shipmentRepository;
    private final RouteScheduleRepository routeScheduleRepository;
    private final TripLogRepository tripLogRepository;
    private final DeliveryRecordRepository deliveryRecordRepository;
    private final ProofOfReceiptRepository proofOfReceiptRepository;
    private final AuditLogRepository auditLogRepository;

    public DriverService(ShipmentRepository shipmentRepository,
                         RouteScheduleRepository routeScheduleRepository,
                         TripLogRepository tripLogRepository,
                         DeliveryRecordRepository deliveryRecordRepository,
                         ProofOfReceiptRepository proofOfReceiptRepository,
                         AuditLogRepository auditLogRepository) {
        this.shipmentRepository = shipmentRepository;
        this.routeScheduleRepository = routeScheduleRepository;
        this.tripLogRepository = tripLogRepository;
        this.deliveryRecordRepository = deliveryRecordRepository;
        this.proofOfReceiptRepository = proofOfReceiptRepository;
        this.auditLogRepository = auditLogRepository;
    }

    @Transactional
    public String verifyAndCompleteDelivery(Long shipmentId, DeliveryCompletionRequest request, Long driverId) {
        Shipment shipment = shipmentRepository.findById(shipmentId)
                .orElseThrow(() -> new RuntimeException("Shipment not found with ID: " + shipmentId));

        if (shipment.getDeliveryOtp() == null || !shipment.getDeliveryOtp().equals(request.getOtp())) {
            throw new RuntimeException("Invalid Delivery OTP.");
        }

        RouteSchedule schedule = routeScheduleRepository.findByShipmentId(shipmentId)
                .orElseThrow(() -> new RuntimeException("No active schedule found."));

        shipment.setStatus(Shipment.ShipmentStatus.DELIVERED);
        shipmentRepository.save(shipment);

        // Trip Log
        TripLog trip = new TripLog();
        trip.setVehicleId(schedule.getVehicleId());
        trip.setDriverId(driverId);
        trip.setRouteId(schedule.getRouteId());
        trip.setEndAt(LocalDateTime.now());
        trip.setNotes(request.getNotes());
        trip.setDistanceKm(request.getDistance());
        trip.setStatus("COMPLETED");
        tripLogRepository.save(trip);

        // Delivery Record
        DeliveryRecord record = new DeliveryRecord();
        record.setOrderId(shipmentId);
        record.setVehicleId(schedule.getVehicleId());
        record.setDriverId(driverId);
        record.setDeliveredAt(LocalDateTime.now());
        record.setStatus("SUCCESS");
        DeliveryRecord savedRecord = deliveryRecordRepository.save(record);

        // Proof of Receipt
        ProofOfReceipt proof = new ProofOfReceipt();
        proof.setDeliveryId(savedRecord.getDeliveryId());
        proof.setCustomerId(shipment.getCustomerId());
        proof.setReceivedAt(LocalDateTime.now());
        proof.setFileUri(request.getFileUri());
        proof.setStatus("VERIFIED");
        proofOfReceiptRepository.save(proof);

        return "Delivery verified and completed.";
    }

    @Transactional(readOnly = true)
    public List<DriverRideResponse> getDriverSchedules(Long driverId) {
        List<RouteSchedule> schedules = routeScheduleRepository.findScheduledRidesByDriverId(driverId);

        return schedules.stream().map(schedule -> {
            DriverRideResponse response = new DriverRideResponse();
            
            response.setScheduleId(schedule.getScheduleId());
            response.setShipmentId(schedule.getShipmentId());
            response.setDepartureAt(schedule.getDepartureAt());
            response.setArrivalAt(schedule.getArrivalAt());
            response.setStatus(schedule.getStatus().name());
            response.setVehicleId(schedule.getVehicleId());
            response.setRouteId(schedule.getRouteId());

            // Fetch details from Shipment using your specific field names
            shipmentRepository.findById(schedule.getShipmentId()).ifPresent(shipment -> {
                response.setOrigin(shipment.getOrigin());           // Fixed mapping
                response.setDestination(shipment.getDestination()); // Fixed mapping
                response.setReceiverName(shipment.getReceiverName());
                response.setReceiverPhone(shipment.getReceiverPhone());
            });

            return response;
        }).collect(Collectors.toList());
    }
    
    @Transactional
    public String startTrip(Long scheduleId, Long driverId) {
        // 1. Find the schedule
        RouteSchedule schedule = routeScheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new RuntimeException("Schedule not found"));

        // 2. Security Check: Ensure this driver is actually assigned to this vehicle/route
        // (Optional but recommended logic here)

        // 3. Update Schedule Status
        schedule.setStatus(RouteSchedule.ScheduleStatus.IN_TRANSIT);
        routeScheduleRepository.save(schedule);

        // 4. Update the linked Shipment Status
        if (schedule.getShipmentId() != null) {
            shipmentRepository.findById(schedule.getShipmentId()).ifPresent(shipment -> {
                shipment.setStatus(Shipment.ShipmentStatus.IN_TRANSIT);
                shipmentRepository.save(shipment);
            });
        }

        // 5. Audit Log
        auditLogRepository.save(new AuditLog(driverId, "TRIP_STARTED", 
            "Driver started trip for Schedule #" + scheduleId));

        return "Trip started. Shipment is now IN_TRANSIT.";
    }
    
    
}