package com.cts.dao;

import com.cts.entity.Driver;
import com.cts.entity.User;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface DriverRepository extends JpaRepository<Driver, Long> {
    // Find driver by the associated User ID
    Optional<Driver> findByUserUserId(Long userId);
    Optional<Driver> findByUser(User user);
}