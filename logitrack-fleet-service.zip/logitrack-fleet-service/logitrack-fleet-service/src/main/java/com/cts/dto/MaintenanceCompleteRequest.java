package com.cts.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class MaintenanceCompleteRequest {
    @NotNull
    private Double cost;

    @NotBlank(message = "Mechanic notes are required for completion")
    private String mechanicNotes;
}