package com.cts.service;

import com.cts.dao.VehicleRepository;
import com.cts.dao.InspectionRepository;
import com.cts.dao.MaintenanceRepository;
import com.cts.dto.InspectionRequest;
import com.cts.dto.MaintenanceCompleteRequest;
import com.cts.dto.VehicleRequest;
import com.cts.entity.Vehicle;
import com.cts.entity.InspectionRecord;
import com.cts.entity.MaintenanceRecord;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class FleetService {

    private final VehicleRepository vehicleRepository;
    private final InspectionRepository inspectionRepository;
    private final MaintenanceRepository maintenanceRepository;

    public FleetService(VehicleRepository vehicleRepository,
                        InspectionRepository inspectionRepository,
                        MaintenanceRepository maintenanceRepository) {
        this.vehicleRepository = vehicleRepository;
        this.inspectionRepository = inspectionRepository;
        this.maintenanceRepository = maintenanceRepository;
    }

    // --- Vehicle Management ---

    @Transactional
    public Vehicle addVehicle(VehicleRequest dto) {
        Vehicle vehicle = new Vehicle();
        vehicle.setRegNumber(dto.getRegNumber());
        vehicle.setType(dto.getType());
        vehicle.setCapacity(dto.getCapacity());
        vehicle.setStatus(Vehicle.VehicleStatus.AVAILABLE);
        return vehicleRepository.save(vehicle);
    }

    @Transactional
    public Vehicle updateVehicle(Long id, VehicleRequest dto) {
        Vehicle vehicle = vehicleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Vehicle not found"));
        vehicle.setRegNumber(dto.getRegNumber());
        vehicle.setType(dto.getType());
        vehicle.setCapacity(dto.getCapacity());
        return vehicleRepository.save(vehicle);
    }

    @Transactional
    public void deleteVehicle(Long id) {
        vehicleRepository.deleteById(id);
    }

    public List<Vehicle> getAllVehicles() {
        return vehicleRepository.findAll();
    }

    // --- Inspection & Maintenance Workflow ---

    @Transactional
    public void recordInspection(InspectionRequest dto) {
        // 1. Create Inspection Record
        InspectionRecord record = new InspectionRecord();
        record.setVehicleId(dto.getVehicleId());
        record.setConditionRating(dto.getConditionRating());
        record.setFindings(dto.getFindings());
        record.setPhotoUri(dto.getPhotoUri());
        record.setStatus(InspectionRecord.InspectionStatus.valueOf(dto.getStatus().toUpperCase()));
        record.setPerformedAt(LocalDateTime.now());

        InspectionRecord savedInspection = inspectionRepository.save(record);

        // 2. Auto-trigger maintenance ticket if FAILED
        if (savedInspection.getStatus() == InspectionRecord.InspectionStatus.FAILED) {
            MaintenanceRecord maint = new MaintenanceRecord();
            maint.setVehicleId(dto.getVehicleId());
            maint.setInspectionId(savedInspection.getInspectionId()); // Linking PK to FK
            maint.setTaskDescription("AUTO-GENERATED: Failed Inspection. Findings: " + dto.getFindings());
            maint.setStatus(MaintenanceRecord.MaintenanceStatus.PENDING);
            maintenanceRepository.save(maint);
        }
    }

    @Transactional
    public void startMaintenance(Long maintId, String mechanicName) {
        MaintenanceRecord maint = maintenanceRepository.findById(maintId)
                .orElseThrow(() -> new RuntimeException("Maintenance ticket not found"));

        // Update Maintenance Entry
        maint.setStatus(MaintenanceRecord.MaintenanceStatus.IN_PROGRESS);
        maint.setPerformedBy(mechanicName);
        maint.setPerformedAt(LocalDateTime.now());
        maintenanceRepository.save(maint);

        // Update Vehicle Status to LOCK it from dispatch
        Vehicle vehicle = vehicleRepository.findById(maint.getVehicleId())
                .orElseThrow(() -> new RuntimeException("Vehicle not found"));
        vehicle.setStatus(Vehicle.VehicleStatus.IN_MAINTENANCE);
        vehicleRepository.save(vehicle);
    }

    @Transactional
    public void completeMaintenance(Long maintId, MaintenanceCompleteRequest dto) {
        MaintenanceRecord maint = maintenanceRepository.findById(maintId)
                .orElseThrow(() -> new RuntimeException("Maintenance ticket not found"));

        // Update Maintenance Entry with final details
        maint.setStatus(MaintenanceRecord.MaintenanceStatus.COMPLETED);
        maint.setCost(dto.getCost());
        maint.setMechanicNotes(dto.getMechanicNotes());
        maintenanceRepository.save(maint);

        // Update Vehicle Status to AVAILABLE for dispatch
        Vehicle vehicle = vehicleRepository.findById(maint.getVehicleId())
                .orElseThrow(() -> new RuntimeException("Vehicle not found"));
        vehicle.setStatus(Vehicle.VehicleStatus.AVAILABLE);
        vehicleRepository.save(vehicle);
    }

    public List<InspectionRecord> getAllInspections() {
        return inspectionRepository.findAll();
    }

    public List<InspectionRecord> getInspectionsByVehicle(Long vehicleId) {
        return inspectionRepository.findByVehicleId(vehicleId);
    }

    public List<MaintenanceRecord> getAllMaintenanceRecords() {
        return maintenanceRepository.findAll();
    }

    public List<MaintenanceRecord> getMaintenanceByVehicle(Long vehicleId) {
        return maintenanceRepository.findByVehicleId(vehicleId);
    }
}