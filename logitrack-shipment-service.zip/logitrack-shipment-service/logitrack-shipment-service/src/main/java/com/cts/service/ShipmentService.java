package com.cts.service;

import com.cts.common.dao.AuditLogRepository;
import com.cts.common.dao.UserRepository;
import com.cts.common.entity.User;
import com.cts.dao.ShipmentRepository;
import com.cts.dto.ShipmentRequest;
import com.cts.entity.Shipment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class ShipmentService {

    private final ShipmentRepository shipmentRepository;
    private final AuditLogRepository auditLogRepository;
    private final UserRepository userRepository;

    public ShipmentService(ShipmentRepository shipmentRepository,
                           AuditLogRepository auditLogRepository,
                           UserRepository userRepository) {
        this.shipmentRepository = shipmentRepository;
        this.auditLogRepository = auditLogRepository;
        this.userRepository = userRepository;
    }

    @Transactional
    public Shipment createShipment(String email, ShipmentRequest request) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Shipment shipment = new Shipment();
        shipment.setCustomerId(user.getUserId());
        shipment.setOrigin(request.getOrigin());
        shipment.setDestination(request.getDestination());
        shipment.setWeight(request.getWeight());
        shipment.setReceiverName(request.getReceiverName());
        shipment.setReceiverPhone(request.getReceiverPhone());
        shipment.setStatus(Shipment.ShipmentStatus.PENDING);

        Shipment saved = shipmentRepository.save(shipment);

        auditLogRepository.save(new AuditLog(user.getUserId(), "SHIPMENT_CREATED",
                "Order #" + saved.getShipmentId() + " placed from " + saved.getOrigin()));

        return saved;
    }

    public Shipment getShipmentStatus(Long shipmentId) {
        return shipmentRepository.findById(shipmentId)
                .orElseThrow(() -> new RuntimeException("Shipment not found"));
    }

    public List<Shipment> getCustomerShipments(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return shipmentRepository.findByCustomerId(user.getUserId());
    }
}

