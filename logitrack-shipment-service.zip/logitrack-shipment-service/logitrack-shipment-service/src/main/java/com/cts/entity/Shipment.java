package com.cts.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;

@Entity
@Table(name = "shipments")
@Data
@EntityListeners(AuditingEntityListener.class)
public class Shipment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long shipmentId;

    @Column(nullable = false)
    private Long customerId; // Linked to User entity

    private String origin;
    private String destination;
    private Double weight;
    private String receiverName;
    private String receiverPhone;

    @Enumerated(EnumType.STRING)
    private ShipmentStatus status; // PENDING, IN_TRANSIT, DELIVERED, CANCELLED

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime orderDate;

    private String deliveryOtp;

    public String getDeliveryOtp() { return deliveryOtp; }
    public void setDeliveryOtp(String deliveryOtp) { this.deliveryOtp = deliveryOtp; }


    public enum ShipmentStatus {
        PENDING, ACCEPTED, IN_TRANSIT, DELIVERED, CANCELLED
    }
}