package com.cts.dao;

import com.cts.entity.ProofOfReceipt;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface ProofOfReceiptRepository extends JpaRepository<ProofOfReceipt, Long> {
    Optional<ProofOfReceipt> findByDeliveryId(Long deliveryId);
}