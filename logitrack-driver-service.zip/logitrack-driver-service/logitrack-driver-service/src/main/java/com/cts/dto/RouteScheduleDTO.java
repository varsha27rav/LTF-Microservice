package com.cts.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class RouteScheduleDTO {
    private Long scheduleId;
    private Long shipmentId;
    private Long vehicleId;
    private Long routeId;
    private LocalDateTime departureAt;
    private LocalDateTime arrivalAt;
    private String status;
}
