package com.cts.service;

import com.cts.client.DispatchClient;
import com.cts.client.ShipmentClient;
import com.cts.common.dao.AuditLogRepository;
import com.cts.common.entity.AuditLog;
import com.cts.dao.DeliveryRecordRepository;
import com.cts.dao.ProofOfReceiptRepository;
import com.cts.dao.TripLogRepository;
import com.cts.dto.DeliveryCompletionRequest;
import com.cts.dto.DriverRideResponse;
import com.cts.dto.RouteScheduleDTO;
import com.cts.dto.ShipmentDTO;
import com.cts.entity.DeliveryRecord;
import com.cts.entity.ProofOfReceipt;
import com.cts.entity.TripLog;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DriverService {

    private final TripLogRepository tripLogRepository;
    private final DeliveryRecordRepository deliveryRecordRepository;
    private final ProofOfReceiptRepository proofOfReceiptRepository;
    private final AuditLogRepository auditLogRepository;
    private final ShipmentClient shipmentClient;
    private final DispatchClient dispatchClient;

    public DriverService(TripLogRepository tripLogRepository,
                         DeliveryRecordRepository deliveryRecordRepository,
                         ProofOfReceiptRepository proofOfReceiptRepository,
                         AuditLogRepository auditLogRepository,
                         ShipmentClient shipmentClient,
                         DispatchClient dispatchClient) {
        this.tripLogRepository = tripLogRepository;
        this.deliveryRecordRepository = deliveryRecordRepository;
        this.proofOfReceiptRepository = proofOfReceiptRepository;
        this.auditLogRepository = auditLogRepository;
        this.shipmentClient = shipmentClient;
        this.dispatchClient = dispatchClient;
    }

    @Transactional
    public String verifyAndCompleteDelivery(Long shipmentId,
                                            DeliveryCompletionRequest request,
                                            Long driverId) {
        // 1. Get Shipment via Feign
        ShipmentDTO shipment = shipmentClient.getShipmentById(shipmentId);

        // 2. Verify OTP
        if (shipment.getDeliveryOtp() == null ||
                !shipment.getDeliveryOtp().equals(request.getOtp())) {
            throw new RuntimeException("Invalid Delivery OTP.");
        }

        // 3. Get Schedule via Feign
        RouteScheduleDTO schedule = dispatchClient
                .getSchedulesByDriverId(driverId)
                .stream()
                .filter(s -> s.getShipmentId().equals(shipmentId))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("No active schedule found."));

        // 4. Update Shipment status via Feign
        shipmentClient.updateShipmentStatus(shipmentId, "DELIVERED");

        // 5. Update Schedule status via Feign
        dispatchClient.updateScheduleStatus(schedule.getScheduleId(), "COMPLETED");

        // 6. Save Trip Log
        TripLog trip = new TripLog();
        trip.setVehicleId(schedule.getVehicleId());
        trip.setDriverId(driverId);
        trip.setRouteId(schedule.getRouteId());
        trip.setEndAt(LocalDateTime.now());
        trip.setNotes(request.getNotes());
        trip.setDistanceKm(request.getDistance());
        trip.setStatus("COMPLETED");
        tripLogRepository.save(trip);

        // 7. Save Delivery Record
        DeliveryRecord record = new DeliveryRecord();
        record.setOrderId(shipmentId);
        record.setVehicleId(schedule.getVehicleId());
        record.setDriverId(driverId);
        record.setDeliveredAt(LocalDateTime.now());
        record.setStatus("SUCCESS");
        DeliveryRecord savedRecord = deliveryRecordRepository.save(record);

        // 8. Save Proof of Receipt
        ProofOfReceipt proof = new ProofOfReceipt();
        proof.setDeliveryId(savedRecord.getDeliveryId());
        proof.setCustomerId(shipment.getCustomerId());
        proof.setReceivedAt(LocalDateTime.now());
        proof.setFileUri(request.getFileUri());
        proof.setStatus("VERIFIED");
        proofOfReceiptRepository.save(proof);

        return "Delivery verified and completed.";
    }

    @Transactional(readOnly = true)
    public List<DriverRideResponse> getDriverSchedules(Long driverId) {
        // Get schedules via Feign
        List<RouteScheduleDTO> schedules = dispatchClient
                .getSchedulesByDriverId(driverId);

        return schedules.stream().map(schedule -> {
            DriverRideResponse response = new DriverRideResponse();
            response.setScheduleId(schedule.getScheduleId());
            response.setShipmentId(schedule.getShipmentId());
            response.setDepartureAt(schedule.getDepartureAt());
            response.setArrivalAt(schedule.getArrivalAt());
            response.setStatus(schedule.getStatus());
            response.setVehicleId(schedule.getVehicleId());
            response.setRouteId(schedule.getRouteId());

            // Get Shipment details via Feign
            ShipmentDTO shipment = shipmentClient
                    .getShipmentById(schedule.getShipmentId());
            response.setOrigin(shipment.getOrigin());
            response.setDestination(shipment.getDestination());
            response.setReceiverName(shipment.getReceiverName());
            response.setReceiverPhone(shipment.getReceiverPhone());

            return response;
        }).collect(Collectors.toList());
    }

    @Transactional
    public String startTrip(Long scheduleId, Long driverId) {
        // Update Schedule status via Feign
        dispatchClient.updateScheduleStatus(scheduleId, "IN_TRANSIT");

        // Get Schedule to find Shipment
        RouteScheduleDTO schedule = dispatchClient.getScheduleById(scheduleId);

        // Update Shipment status via Feign
        if (schedule.getShipmentId() != null) {
            shipmentClient.updateShipmentStatus(
                    schedule.getShipmentId(), "IN_TRANSIT");
        }

        // Audit Log
        auditLogRepository.save(new AuditLog(driverId, "TRIP_STARTED",
                "Driver started trip for Schedule #" + scheduleId));

        return "Trip started. Shipment is now IN_TRANSIT.";
    }
}