package com.cts.client;

import com.cts.dto.RouteScheduleDTO;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;

@Component
public class DispatchClientFallback implements DispatchClient {

    @Override
    public RouteScheduleDTO getScheduleById(Long scheduleId) {
        RouteScheduleDTO fallback = new RouteScheduleDTO();
        fallback.setScheduleId(scheduleId);
        fallback.setStatus("SERVICE_UNAVAILABLE");
        return fallback;
    }

    @Override
    public List<RouteScheduleDTO> getSchedulesByDriverId(Long driverId) {
        return new ArrayList<>();
    }

    @Override
    public void updateScheduleStatus(Long scheduleId, String status) {
        System.err.println("DispatchService is down. Cannot update schedule: " + scheduleId);
    }
}