package com.cts.client;

import com.cts.dto.ShipmentDTO;
import org.springframework.stereotype.Component;

@Component
public class ShipmentClientFallback implements ShipmentClient {

    @Override
    public ShipmentDTO getShipmentById(Long id) {
        ShipmentDTO fallback = new ShipmentDTO();
        fallback.setShipmentId(id);
        fallback.setStatus("SERVICE_UNAVAILABLE");
        return fallback;
    }

    @Override
    public void updateShipmentStatus(Long id, String status) {
        System.err.println("ShipmentService is down. Cannot update status for shipment: " + id);
    }
}