package com.cts.entity;

import java.time.LocalDateTime;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "trip_logs")
@Data
public class TripLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long tripId;
    private Long vehicleId;
    private Long driverId;
    private Long routeId;
    private LocalDateTime startAt;
    private LocalDateTime endAt;
    private Double distanceKm;
    private String notes;
    private String status; // STARTED, COMPLETED
}
