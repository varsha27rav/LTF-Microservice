package com.cts.controller;

import com.cts.dao.RouteScheduleRepository;
import com.cts.entity.RouteSchedule;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/dispatcher/schedules")
public class ScheduleController {

    private final RouteScheduleRepository routeScheduleRepository;

    public ScheduleController(RouteScheduleRepository routeScheduleRepository) {
        this.routeScheduleRepository = routeScheduleRepository;
    }

    @GetMapping("/{scheduleId}")
    public ResponseEntity<RouteSchedule> getScheduleById(
            @PathVariable Long scheduleId) {
        return ResponseEntity.ok(routeScheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new RuntimeException("Schedule not found")));
    }

    @GetMapping("/driver/{driverId}")
    public ResponseEntity<List<RouteSchedule>> getSchedulesByDriverId(
            @PathVariable Long driverId) {
        return ResponseEntity.ok(
                routeScheduleRepository.findScheduledRidesByDriverId(driverId));
    }

    @PutMapping("/{scheduleId}/status")
    public ResponseEntity<?> updateScheduleStatus(
            @PathVariable Long scheduleId,
            @RequestBody String status) {
        RouteSchedule schedule = routeScheduleRepository
                .findById(scheduleId)
                .orElseThrow(() -> new RuntimeException("Schedule not found"));
        schedule.setStatus(RouteSchedule.ScheduleStatus.valueOf(status));
        routeScheduleRepository.save(schedule);
        return ResponseEntity.ok().build();
    }
}
