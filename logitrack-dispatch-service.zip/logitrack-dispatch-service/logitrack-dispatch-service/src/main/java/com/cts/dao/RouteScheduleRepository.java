package com.cts.dao;

import com.cts.entity.RouteSchedule;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RouteScheduleRepository extends JpaRepository<RouteSchedule, Long> {
    Optional<RouteSchedule> findByVehicleIdAndRouteIdAndStatus(Long vehicleId, Long routeId, RouteSchedule.ScheduleStatus status);
    Optional<RouteSchedule> findByShipmentId(Long shipmentId);

    @Query("SELECT rs FROM RouteSchedule rs JOIN DriverAssignment da ON rs.vehicleId = da.vehicleId " +
            "WHERE da.driverId = :driverId AND rs.status = 'SCHEDULED'")
    List<RouteSchedule> findScheduledRidesByDriverId(@Param("driverId") Long driverId);
}