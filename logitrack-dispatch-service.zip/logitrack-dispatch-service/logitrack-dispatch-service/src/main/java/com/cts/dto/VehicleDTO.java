package com.cts.dto;

import lombok.Data;

@Data
public class VehicleDTO {
    private Long vehicleId;
    private String regNumber;
    private String type;
    private Double capacity;
    private String status;
}

