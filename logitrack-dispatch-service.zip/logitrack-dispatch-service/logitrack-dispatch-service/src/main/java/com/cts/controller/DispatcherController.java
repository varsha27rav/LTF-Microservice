
package com.cts.controller;

import com.cts.client.ShipmentClient;
import com.cts.common.dao.AuditLogRepository;
import com.cts.common.dao.UserRepository;
import com.cts.common.entity.AuditLog;
import com.cts.common.entity.User;
import com.cts.dto.DispatchRequest;
import com.cts.dto.ShipmentDTO;
import com.cts.service.DispatcherService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dispatcher")
@PreAuthorize("hasAnyRole('ADMIN', 'DISPATCHER')")
public class DispatcherController {

    private final DispatcherService dispatcherService;
    private final ShipmentClient shipmentClient;
    private final AuditLogRepository auditLogRepository;
    private final UserRepository userRepository;

    public DispatcherController(DispatcherService dispatcherService,
                                ShipmentClient shipmentClient,
                                AuditLogRepository auditLogRepository,
                                UserRepository userRepository) {
        this.dispatcherService = dispatcherService;
        this.shipmentClient = shipmentClient;
        this.auditLogRepository = auditLogRepository;
        this.userRepository = userRepository;
    }

    @GetMapping("/shipments")
    public ResponseEntity<List<ShipmentDTO>> getShipments() {
        // Get all shipments via Feign
        return ResponseEntity.ok(shipmentClient.getAllShipments());
    }

    @PutMapping("/shipments/{id}/cancel")
    public ResponseEntity<?> cancelShipment(@PathVariable Long id, Authentication auth) {
        shipmentClient.updateShipmentStatus(id, "CANCELLED");
        User dispatcher = userRepository.findByEmail(auth.getName()).orElseThrow();
        auditLogRepository.save(new AuditLog(dispatcher.getUserId(),
                "SHIPMENT_CANCELLED", "Dispatcher cancelled shipment ID: " + id));
        return ResponseEntity.ok(Map.of("message", "Shipment cancelled successfully."));
    }

    @PostMapping("/dispatch")
    public ResponseEntity<?> processDispatch(Authentication auth,
                                             @RequestBody DispatchRequest request) {
        User dispatcher = userRepository.findByEmail(auth.getName()).orElseThrow();
        dispatcherService.dispatchShipment(request, dispatcher.getUserId());
        return ResponseEntity.ok(Map.of("message", "Shipment dispatched successfully."));
    }

    @PutMapping("/shipments/{id}/cancel-dispatch")
    public ResponseEntity<?> cancelDispatch(@PathVariable Long id, Authentication auth) {
        User dispatcher = userRepository.findByEmail(auth.getName()).orElseThrow();
        dispatcherService.cancelFullDispatch(id, dispatcher.getUserId());
        return ResponseEntity.ok(Map.of("message", "Dispatch cancelled successfully."));
    }
}


