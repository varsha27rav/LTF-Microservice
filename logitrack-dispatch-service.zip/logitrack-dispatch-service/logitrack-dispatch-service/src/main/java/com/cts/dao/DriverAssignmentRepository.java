package com.cts.dao;

import com.cts.entity.DriverAssignment;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DriverAssignmentRepository extends JpaRepository<DriverAssignment, Long> {
    Optional<DriverAssignment> findByDriverIdAndVehicleIdAndStatus(Long driverId, Long vehicleId, String status);
}