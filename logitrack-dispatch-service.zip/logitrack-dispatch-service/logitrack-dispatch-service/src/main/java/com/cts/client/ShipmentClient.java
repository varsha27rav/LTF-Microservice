package com.cts.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cts.dto.ShipmentDTO;

import java.util.List;

@FeignClient(name = "logitrack-shipment-service",fallback = ShipmentClientFallback.class)
public interface ShipmentClient {

    @GetMapping("/api/shipments/{id}")
    ShipmentDTO getShipmentById(@PathVariable Long id);

    @PutMapping("/api/shipments/{id}/status")
    void updateShipmentStatus(@PathVariable Long id, @RequestBody String status);

    @GetMapping("/api/shipments/all")
    List<ShipmentDTO> getAllShipments();
}
