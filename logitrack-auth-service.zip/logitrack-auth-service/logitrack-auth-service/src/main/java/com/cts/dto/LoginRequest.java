package com.cts.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

//@Data
@Schema(description = "Request body for user login")
public class LoginRequest {

    @Schema(example = "user@example.com", requiredMode = Schema.RequiredMode.REQUIRED)
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Schema(example = "your_password", requiredMode = Schema.RequiredMode.REQUIRED)
    private String password;


}