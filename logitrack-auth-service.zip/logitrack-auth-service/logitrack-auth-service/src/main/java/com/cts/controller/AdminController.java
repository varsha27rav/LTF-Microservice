package com.cts.controller;

import com.cts.common.constants.Role;
import com.cts.common.constants.Status;
import com.cts.common.dao.AuditLogRepository;
import com.cts.common.dao.UserRepository;
import com.cts.common.entity.AuditLog;
import com.cts.common.entity.User;
import com.cts.dto.UserPromotionDTO;
import com.cts.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final UserService userService;
    private final UserRepository userRepository;
    private final AuditLogRepository auditLogRepository;

    public AdminController(UserService userService,
                           UserRepository userRepository,
                           AuditLogRepository auditLogRepository) {
        this.userService = userService;
        this.userRepository = userRepository;
        this.auditLogRepository = auditLogRepository;
    }

    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userRepository.findAll());
    }

    @GetMapping("/users/role/{role}")
    public ResponseEntity<List<User>> getUsersByRole(@PathVariable Role role) {
        return ResponseEntity.ok(userRepository.findByRole(role));
    }

    @PutMapping("/users/{id}/updateRole")
    public ResponseEntity<Map<String, String>> promoteUser(
            @PathVariable Long id,
            @RequestBody UserPromotionDTO dto,
            Authentication auth) {
        userService.promoteUser(id, dto);
        userRepository.findByEmail(auth.getName()).ifPresent(admin ->
                auditLogRepository.save(new AuditLog(admin.getUserId(),
                        "ROLE_UPDATE", "Role updated to: " + dto.getNewRole())));
        return ResponseEntity.ok(Map.of("message", "Role updated to " + dto.getNewRole()));
    }

    @PutMapping("/users/{id}/reactivate")
    public ResponseEntity<Map<String, String>> reactivateUser(
            @PathVariable Long id,
            Authentication auth) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        user.setStatus(Status.ACTIVE);
        userRepository.save(user);
        userRepository.findByEmail(auth.getName()).ifPresent(admin ->
                auditLogRepository.save(new AuditLog(admin.getUserId(),
                        "REACTIVATION", "Reactivated: " + user.getEmail())));
        return ResponseEntity.ok(Map.of("message", "User reactivated successfully."));
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<Map<String, String>> deactivateUser(
            @PathVariable Long id,
            Authentication auth) {
        userService.deactivateUser(id);
        userRepository.findByEmail(auth.getName()).ifPresent(admin ->
                auditLogRepository.save(new AuditLog(admin.getUserId(),
                        "DEACTIVATION", "Deactivated user ID: " + id)));
        return ResponseEntity.ok(Map.of("message", "User deactivated successfully."));
    }

    @GetMapping("/audit-logs")
    public ResponseEntity<List<AuditLog>> getAuditLogs() {
        return ResponseEntity.ok(auditLogRepository.findAllByOrderByTimestampDesc());
    }
}
