package com.cts.common.service;


import org.springframework.stereotype.Service;

@Service
public class SmsService {
    public void sendSmsOtp(String phoneNumber, String otp) {
        System.out.println("************************************************");
        System.out.println("  LOGITRACK MOCK SMS SERVICE                  ");
        System.out.println("  To: " + phoneNumber                          );
        System.out.println("  OTP: " + otp                                 );
        System.out.println("************************************************");
    }
}