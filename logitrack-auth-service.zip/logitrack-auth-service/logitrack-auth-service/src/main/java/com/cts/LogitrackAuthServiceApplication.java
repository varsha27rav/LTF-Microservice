package com.cts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EnableJpaAuditing
@EntityScan(basePackages = {
        "com.cts.common.entity",
        "com.cts.common.entity"
})
@EnableJpaRepositories(basePackages = {
        "com.cts.dao",
        "com.cts.common.dao"
})
public class LogitrackAuthServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(LogitrackAuthServiceApplication.class, args);
    }
}