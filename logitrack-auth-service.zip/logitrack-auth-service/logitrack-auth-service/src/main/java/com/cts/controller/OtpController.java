package com.cts.controller;

import com.cts.service.OtpService;
import com.cts.common.service.EmailService;
import com.cts.dto.OtpRequest;
import com.cts.dto.OtpVerificationRequest;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.HashMap;


@RestController
@RequestMapping("/api/otp")
public class OtpController {
    private final OtpService otpService;
    private final EmailService emailService;

    public OtpController(OtpService otpService, EmailService emailService) {
        this.otpService = otpService;
        this.emailService = emailService;
    }

    @PostMapping("/request")
    public ResponseEntity<?> requestOtp(@RequestBody OtpRequest request) {
        String code = otpService.generateAndSaveOtp(request.getEmail());
        emailService.sendOtpEmail(request.getEmail(), code);
        return ResponseEntity.ok(Map.of("message", "OTP sent to " + request.getEmail()));
    }

    @PostMapping("/verify")
    public ResponseEntity<?> verifyOtp(@RequestBody OtpVerificationRequest request) {
        boolean isValid = otpService.validateOtp(request.getEmail(), request.getCode());
        if (isValid) {
            return ResponseEntity.ok(Map.of("success", true, "message", "OTP Verified"));
        }
        return ResponseEntity.status(400).body(Map.of("success", false, "message", "Invalid or Expired OTP"));
    }
}