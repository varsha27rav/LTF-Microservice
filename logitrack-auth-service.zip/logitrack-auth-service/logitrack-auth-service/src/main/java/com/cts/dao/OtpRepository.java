package com.cts.dao;

import com.cts.entity.OtpEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface OtpRepository extends JpaRepository<OtpEntity, Long> {
    Optional<OtpEntity> findByEmailAndCode(String email, String code);
    void deleteByEmail(String email);
}